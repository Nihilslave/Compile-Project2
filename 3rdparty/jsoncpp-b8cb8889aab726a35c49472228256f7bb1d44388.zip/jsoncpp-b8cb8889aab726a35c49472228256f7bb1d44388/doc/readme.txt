The documentation is generated using doxygen (http://www.doxygen.org).
